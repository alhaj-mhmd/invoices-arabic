
(function($) {
    "use strict";	
	
		// ______________Nice Select	
	$('select.nice-select').niceSelect();
})(jQuery);